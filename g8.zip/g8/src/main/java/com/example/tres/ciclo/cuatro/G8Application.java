package com.example.tres.ciclo.cuatro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G8Application {

	public static void main(String[] args) {
		SpringApplication.run(G8Application.class, args);
	}

}
