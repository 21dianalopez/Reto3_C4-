package com.example.g8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class G8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
